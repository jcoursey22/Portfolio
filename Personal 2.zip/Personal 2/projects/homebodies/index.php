<!DOCTYPE html>

<htnml>

<head>
<title>Home Bodies</title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style>
body {
	font-family: Verdana;
}
a {
	color:#3d4355;
}
</style>
</head>

<body style="background-color:#eef3f7;">

<nav class="navbar">

  <div class="container">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Home Bodies</a>
    </div>
    <ul class="nav navbar-nav"></ul>
    <ul class="nav navbar-nav navbar-right">
   <li class="active">
    <li class="active"><a href="#">HOME</a></li>
    <li class="active"><a href="#">SERVICES</a></li>
    <li class="active"><a href="#">ABOUT</a></li>
    <li class="active"><a href="#">THE TEAM</a></li>
    <li class="active"><a href="#">PRICING</a></li>
    <li class="active"><a href="#">CONTACT</a></li>
</ul>
</div>
</nav>

<div class="container"><div class="row">
<div class="col-md-6 text-center"><img src="images/one.png" class="img-responsive"></div>
<div class="col-md-6 text-center"><img src="images/two.png" class="img-responsive"></div>
</div></div>
<div class="container-fluid" style="background-color:#ffffff;"><div class="row">
<div class="col-md-3 text-center"></div>
<div class="col-md-6 text-center" style="padding:100px;"><h1>We Provide Great Services</h1>
<span style="color:gray;">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</span>
</div>
<div class="col-md-3 text-center"></div>
</div></div>
<div class="container-fluid" style="background-color:#ffffff;padding-bottom:100px;"><div class="row">
<div class="col-md-2 text-center"></div>
<div class="col-md-8 text-center"><img src="images/bottom.png" class="img-responsive"></div>
<div class="col-md-2 text-center"></div>
</div></div>
</body>
</html>
