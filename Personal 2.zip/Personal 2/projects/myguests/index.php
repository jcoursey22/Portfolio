<!DOCTYPE html>
<html>
<head>
<title>My Guests</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-12">
<?php
$servername = "localhost";
$username = "jan25";
$password = "BTd7Kpb3xhqx5";
$dbname = "jan25";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
// Delete Guest
if(isset($_POST['deleteguest'])) {
  // sql to delete a record
$sql = "DELETE FROM MyGuests WHERE id='{$_POST['id']}'";
if (mysqli_query($conn, $sql)) {
  echo '<div class="alert alert-danger">
    <strong>Aww!</strong> Guest deleted.
  </div>';
} else {
  echo "Error deleting record: " . mysqli_error($conn);
}
}
// Add Guest
if(isset($_POST['addguest'])) {
  $sql = "INSERT INTO MyGuests (firstname, lastname, email)
  VALUES ('{$_POST['firstname']}', '{$_POST['lastname']}', '{$_POST['email']}')";
  if (mysqli_query($conn, $sql)) {
    echo '<div class="alert alert-success">
    <strong>Success!</strong> Guest added.
  </div>';
  } else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }
}
?>
<h1>My Guests</h1>
<form action="index.php" method="POST">
First name <input type="text" name="firstname" value="John" required><br>
Last name <input type="text" name="lastname" value="Doe" required><br>
Email <input type="email" name="email" value="John@Doe.com" required><br>
<button type="submit" name="addguest" class="btn btn-success">Add Guest</button>
</form>
<br><br>
<table class="table table-hover table-striped">
  <tr>
    <th>ID</th>
    <th>First</th>
    <th>Last</th>
    <th>Email</th>
    <th>Reg Date</th>
    <th></th>
    <th></th>
</tr>
<?php
$sql = "SELECT * FROM MyGuests";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
  // output data of each row
  while($row = mysqli_fetch_assoc($result)) {
  ?>
<tr>
<td><?=$row['id']?></td>
<td><?=$row['firstname']?></td>
<td><?=$row['lastname']?></td>
<td><?=$row['email']?></td>
<td><?=$row['reg_date']?></td>
<td>edit</td>
<td>
  <form action="index.php" method="POST">
  <input type="hidden" name="id" value="<?=$row['id']?>">
<button type="submit" class="btn btn-danger btn-xs" name="deleteguest">X</button>
  </form>
</td>
</tr>
<?php
  }
} else {
  echo "0 results";
}
mysqli_close($conn);
?>
</table>
</div>
</div></div>
</body>
</html>