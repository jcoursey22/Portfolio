<form action="index.php" method="POST">
<button type="submit" name="makepages">Generate Website</button>
</form><br><br>
<?php
if(isset($_POST['makepages'])) {
$x = 1;
while($x <= 100) {
$myfile = fopen("pages/".$x.".html", "w") or die("Unable to open file!");
$timesitself = $x * $x;
$prev = $x - 1;
$prevlink = '<a href="'.$prev.'.html">Prev</a>';
if($prev == 0) {
$prevlink = 'No more';
}
$next = $x + 1;
$nextlink = '<a href="'.$next.'.html">Next</a>';
if($next == 101) {
$nextlink = 'No more';
}
$txt = <<<HELLO
<!DOCTYPE html>
<html>
<body>
$prevlink | <a href="../index.php">Home</a> | $nextlink
<h1>The number is $x</h1>
The number times itself is: $x X $x = $timesitself
</body>
</html>
HELLO;
fwrite($myfile, $txt);
fclose($myfile);
echo 'Page Created! <a href="pages/'.$x.'.html">Page '.$x.'</a><br>';
$x++;
}
}
?>